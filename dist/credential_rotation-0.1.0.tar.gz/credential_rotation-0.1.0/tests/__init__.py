"""Tests for credential-rotation package."""
